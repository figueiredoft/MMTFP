------ Como foram geradas as instancias -----

Para cada classe: há 3 matrizes de requisições R1, R2 e R3 e 5 matrizes de distribuição de habilidade K1 e K2. Foram geradas 5 combinações (R,K):

C1 - (R1, K1)
C2 - (R1, K2)
C3 - (R2, K3)
C4 - (R2, K4)
C5 - (R3, K5)

Sobre as matrizes sociométricas sintéticas:

Foram criadas 3 matriz considerando a imputação das arestas positivas (30%, 50%, 70%). As arestas restantes foram imputados valores negativos e neutros com a proporção 25% e 75% respectivamente.

Sobre as matrizes socimetricas reais: geradas através de um algoritmo metaheurístico % de arestas negativas e positivas encontram-se na tabela do artigo.